#! /bin/bash
cd /opt/Java_Bytecode_Editor
java ee/ioc/cs/jbe/browser/BrowserApplication &
